assets
======

don't delete the directory
