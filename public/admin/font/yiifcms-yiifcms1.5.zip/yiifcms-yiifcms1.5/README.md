#yiifcms打造顶级内容管理系统


##简介
yiifcms是基于yii framework 1.1.14 个人开发的cms  目前已开发到 1.5版本

  * 官方网址[1.4.1_release]：http://www.yiifcms.com/
  * 官方论坛[Discuz X3.1]：http://bbs.yiifcms.com/
  * 演示案例[1.5_beta]：http://demo.yiifcms.com/

##功能
目前cms功能有：
   * 用户注册、登录, 邮箱激活，支持第三方授权登录(腾讯QQ、新浪微博、人人网)
   * 文章、图集、软件、视频四大内容模型，附加评论与回复功能
   * 后台邮箱设置、模板设置、SEO优化、数据库管理、缓存设置和更新
   * 后台广告位、推荐位、标签、关键字自动获取、邮件日志
   * 默认KindEditor编辑器 利用widget自定义参数
   * 用户中心功能: 修改资料、访问个人空间、修改邮箱、找回密码、收藏和关注、管理好友等
   * 前端默认模板一套default、SetFlash提示、SEO自定义 

##安装
   * 解压到网站根目录 (eg:D:\xampp\htdocs\www\yiifcms1.5)
   * 访问浏览器: http://localhost/yiifcms1.5
   * 按照步骤安装1-7:  数据库需要手动创建好

##备注
  欢迎有兴趣的童鞋 下载并使用 如果您有关于yiifcms的问题 可以致邮：xb_zjh@126.com  
  或者+私人QQ：326196998
  你们的支持是我最大的动力，目前更多功能正在开发，欢迎多提建议。
